
import React from 'react';
import { CursorProvider } from './components/Cursor';
import Prism from './components/Prism';
import TiltedCard from './components/TiltedCard';

export default function App() {
  return (
    <CursorProvider>
      {/* Background Prism */}
      <div className="fixed inset-0 -z-10 opacity-50">
        <Prism
          animationType="3drotate"
          height={3.5}
          baseWidth={5.5}
          glow={1.5}
          noise={0}
          scale={3.6}
          timeScale={0.2}
          suspendWhenOffscreen
        />
      </div>

      {/* Maintenance Content */}
      <div className="bg-transparent text-gray-300 h-full w-full flex items-center justify-center text-center">
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Logo */}
            <div className="mx-auto h-auto w-full max-w-2xl mb-8">
                <TiltedCard
                    imageSrc="https://plexview.ca/assets/Nolet__andrews_blanc-CHc9YYqz.png"
                    altText="Groupe Nolet & Andrews"
                    containerWidth="100%"
                    containerHeight="300px"
                    imageWidth="100%"
                    imageHeight="300px"
                    scaleOnHover={1.05}
                    rotateAmplitude={8}
                    showMobileWarning={false}
                    showTooltip={false}
                />
            </div>
            
            {/* Maintenance Text */}
            <h1 className="sr-only">Groupe Nolet & Andrews</h1>
            <p className="mt-4 max-w-2xl mx-auto text-3xl text-gray-300">
                Notre site web est en pleine reconstruction.
                <br />
                Revenez bientôt pour découvrir notre nouvelle plateforme.
            </p>
        </div>
      </div>
    </CursorProvider>
  );
}
